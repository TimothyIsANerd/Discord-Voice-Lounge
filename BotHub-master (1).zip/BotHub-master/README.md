# Bot-Hub
Bot Hub is a site to help Discord bots grow!
Made by ```Timothy#3773``` and ```Pie#9196```
https://thefallingpie.github.io/BotHub/index.html
